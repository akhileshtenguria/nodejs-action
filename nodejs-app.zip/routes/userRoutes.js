import express from 'express';
import { createUser, userList } from '../controllers/usersController.js';
const router = express.Router();


router.get('/', userList)

router.post('/', createUser);


export default router;